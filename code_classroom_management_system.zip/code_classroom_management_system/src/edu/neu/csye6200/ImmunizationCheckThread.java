package edu.neu.csye6200;

import edu.neu.csye6200.immunisations.AbstractImmunization;

public class ImmunizationCheckThread implements Runnable {

	@Override
	public void run() {
		// TODO Auto-generated method stub
//		for(Student s : GroupHelper.students) {
//			for(AbstractImmunization i : s.getImmunisations()) {
//				i.checkImmunization(s);
//			}
//		}
		
		
	}
	
	

}
